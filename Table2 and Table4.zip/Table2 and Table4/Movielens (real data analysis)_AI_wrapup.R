
rm(list=ls())
dir = "C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/AI"
setwd(dir)

alpha.list = c(0,1,5,10,20,50,100,Inf)

out = c()
for(i in 1:length(alpha.list)){
#i=1
	alpha = alpha.list[i]
	load(paste("movielens_err",alpha,".RData",sep=""))
	out[[i]] = out.AI	
	rm(out.AI)
}



