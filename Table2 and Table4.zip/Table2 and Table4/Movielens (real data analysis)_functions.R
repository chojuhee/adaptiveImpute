
####################
## measure Errors ##
####################

NMAE.and.MSE = function(Mhat, testdata, n, Mmax = 5, Mmin = 1){
	IND = (testdata[,1]-1)*n + testdata[,2]
	abs.diff = abs(Mhat[IND] - testdata[,3])
	mean.abs.diff = mean(abs.diff)
	nmae = mean.abs.diff/(Mmax-Mmin)
	abs.diff.sq = abs.diff^2
	mse = mean(abs.diff.sq)
	return(list(nmae=nmae,mse=mse))
}

proj.onto.15 = function(Mhat, Mmax = 5, Mmin = 1){
	Mhat.r = Mhat
	Mhat.r[Mhat.r<Mmin] = Mmin
	Mhat.r[Mhat.r>Mmax] = Mmax

	return(Mhat.r)
}

