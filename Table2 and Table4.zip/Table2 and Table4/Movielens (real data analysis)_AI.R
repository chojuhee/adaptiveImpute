
rm(list=ls())
setwd("C:/Users/juhee/Dropbox/My Research/LRMC/jcgs-template/AI")
library(softImpute)
source("Movielens (real data analysis)_functions.r")
source("AI.r")


load("Movielens.Rdata")
ls()

alpha = 0     #0,1,5,10,20,50,100,Inf
minV = 1 - alpha
maxV = 5 + alpha

out.AI = matrix(0,5,2)
colnames(out.AI) = c("nmae","mse")

#1
traindata = as.matrix(dat1)
testdata = dat1.test
ind = traindata!=0
n = nrow(traindata)
AI1 = adaptImpute(traindata,r=3,sparse=TRUE,sign.choice = "greedy",
				min.value=minV,max.value=maxV,tol=1e-07,itmax=500)
err1 = NMAE.and.MSE(AI1, testdata,n)
out.AI[1,1] = err1$nmae
out.AI[1,2] = err1$mse

#
traindata = as.matrix(dat2)
testdata = dat2.test
ind = traindata!=0
n = nrow(traindata)
AI2 = adaptImpute(traindata,r=3,sparse=TRUE,sign.choice = "greedy",
				min.value=minV,max.value=maxV,tol=1e-07,itmax=500)
err2 = NMAE.and.MSE(AI2, testdata,n)
out.AI[2,1] = err2$nmae
out.AI[2,2] = err2$mse

#
traindata = as.matrix(dat3)
testdata = dat3.test
ind = traindata!=0
n = nrow(traindata)
AI3 = adaptImpute(traindata,r=3,sparse=TRUE,sign.choice = "greedy",
				min.value=minV,max.value=maxV,tol=1e-07,itmax=500)
err3 = NMAE.and.MSE(AI3, testdata,n)
out.AI[3,1] = err3$nmae
out.AI[3,2] = err3$mse

#
traindata = as.matrix(dat4)
testdata = dat4.test
ind = traindata!=0
n = nrow(traindata)
AI4 = adaptImpute(traindata,r=3,sparse=TRUE,sign.choice = "greedy",
				min.value=minV,max.value=maxV,tol=1e-07,itmax=500)
err4 = NMAE.and.MSE(AI4, testdata,n)
out.AI[4,1] = err4$nmae
out.AI[4,2] = err4$mse

#
traindata = as.matrix(dat5)
testdata = dat5.test
ind = traindata!=0
n = nrow(traindata)
AI5 = adaptImpute(traindata,r=3,sparse=TRUE,sign.choice = "greedy",
				min.value=minV,max.value=maxV,tol=1e-07,itmax=500)
err5 = NMAE.and.MSE(AI5, testdata,n)
out.AI[5,1] = err5$nmae
out.AI[5,2] = err5$mse

save(out.AI,file=paste("movielens_err",alpha,".RData",sep=""))


