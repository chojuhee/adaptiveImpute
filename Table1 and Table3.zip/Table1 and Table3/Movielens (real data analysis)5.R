
rm(list=ls())
setwd("C:/Users/juhee/Dropbox/My Research/LRMC/jcgs-template/AI")
library(softImpute)
source("Movielens (real data analysis)_functions.r")
source("AI.r")

load("Movielens.Rdata")
ls()

#############################################################################

#svd.total = svd(datTotal)
#length(svd.total$d)
#gap = (svd.total$d[1:942]-svd.total$d[2:943])/svd.total$d[2:943]
#cbind(1:40,round(gap*100)[1:40])

r.candid = c(3,5,6,7,8,9,10,12,13,15,16,17,18,20,24,31)
nr = length(r.candid)
#lambda.candid = c(0.001,0.005,0.01,0.05,0.1,0.5,1,5,10,50,100)
lambda.candid = c(0.00001,0.00005,0.0001,0.0005,0.001,0.005,0.01,10,30,50,75,100)
nl = length(lambda.candid)

#############################################################################

testdata = dat5.test
traindata = as.matrix(dat5)
traindata = rbind(traindata,matrix(0,3,ncol(dat5)))
ind = traindata!=0
n = nrow(traindata)

SI.o.als.nmae = SI.o.svd.nmae = 
SI.o.als.mse = SI.o.svd.mse = 
SI.r.als.nmae = SI.r.svd.nmae = 
SI.r.als.mse = SI.r.svd.mse = matrix(0,nr,nl)
for(i in 1:nr){#i=1
	r.AI = r.SI = r.candid[i]
	print(paste("i=",i,"(out of ",nr,")",sep=""))
for(j in 1:nl){#j=1
	lambda.o = lambda.r = lambda.candid[j]

	if(i==1){
		out1 = softImpute(traindata, rank.max = 100, lambda = lambda.o, 
						type = "als", maxit=100)
		out1.mat = out1$u %*% (tcrossprod(diag(out1$d),out1$v))
		out1.mat = proj.onto.15(out1.mat)
		err1 = NMAE.and.MSE(out1.mat, testdata,n)
		print(paste("nmae",err1$nmae,"mse",err1$mse,"when lambda",lambda.o,"and max rank"))
		SI.o.als.nmae[i,j] = err1$nmae
		SI.o.als.mse[i,j] = err1$mse

		out2 = softImpute(traindata, rank.max = 100, lambda = lambda.o, 
						type = "svd", maxit=100)
		out2.mat = out2$u %*% (tcrossprod(diag(out2$d),out2$v))
		out2.mat = proj.onto.15(out2.mat)
		err2 = NMAE.and.MSE(out2.mat, testdata,n)
		print(paste("nmae",err2$nmae,"mse",err2$mse,"when lambda",lambda.o,"and max rank"))
		SI.o.svd.nmae[i,j] = err2$nmae
		SI.o.svd.mse[i,j] = err2$mse
	}

	out3 = softImpute(traindata, rank.max = r.SI, lambda = lambda.r, 
						type = "als", maxit=100)
	out3.mat = out3$u %*% (tcrossprod(diag(out3$d),out3$v))
	out3.mat = proj.onto.15(out3.mat)
	err3 = NMAE.and.MSE(out3.mat, testdata,n)
	print(paste("nmae",err3$nmae,"mse",err3$mse,"when lambda",lambda.o,"and rank",r.SI))
	SI.r.als.nmae[i,j] = err3$nmae
	SI.r.als.mse[i,j] = err3$mse

	out4 = softImpute(traindata, rank.max = r.SI, lambda = lambda.r, 
						type = "svd", maxit=100)
	out4.mat = out4$u %*% (tcrossprod(diag(out4$d),out4$v))
	out4.mat = proj.onto.15(out4.mat)
	err4 = NMAE.and.MSE(out4.mat, testdata,n)
	print(paste("nmae",err4$nmae,"mse",err4$mse,"when lambda",lambda.o,"and rank",r.SI))
	SI.r.svd.nmae[i,j] = err4$nmae
	SI.r.svd.mse[i,j] = err4$mse

	print(j/nl)
}}

what = SI.o.svd.mse #SI.o.als.nmae,SI.o.svd.nmae,SI.o.als.mse,SI.o.svd.mse
min(what[1,])
lambda.candid[which.min(what[1,])]
#50

what = SI.r.svd.mse #SI.r.als.nmae,SI.r.svd.nmae,SI.r.als.mse,SI.r.svd.mse
r.candid[apply(what,2,which.min)]
lambda.candid[which.min(apply(what,2,min))]
#0.00001,0.00005

###

outM5 = matrix(0,4,2)
colnames(outM5) = c("nmae","mse")
rownames(outM5) = c("o.als","o.svd","r.als","r.svd")

#
lambda.out1 = lambda.candid[which.min(SI.o.als.nmae[1,])]
out1 = softImpute(traindata, rank.max = 50, lambda = lambda.out1, 
				type = "als", maxit=500)
out1.mat = out1$u %*% (tcrossprod(diag(out1$d),out1$v))
out1.mat = proj.onto.15(out1.mat)
err1 = NMAE.and.MSE(out1.mat, testdata,n)
outM5[1,1] = err1$nmae

lambda.out1 = lambda.candid[which.min(SI.o.als.mse[1,])]
out1 = softImpute(traindata, rank.max = 50, lambda = lambda.out1, 
				type = "als", maxit=500)
out1.mat = out1$u %*% (tcrossprod(diag(out1$d),out1$v))
out1.mat = proj.onto.15(out1.mat)
err1 = NMAE.and.MSE(out1.mat, testdata,n)
outM5[1,2] = err1$mse

#
lambda.out2 = lambda.candid[which.min(SI.o.svd.nmae[1,])]
out2 = softImpute(traindata, rank.max = 50, lambda = lambda.out2, 
				type = "svd", maxit=500)
out2.mat = out2$u %*% (tcrossprod(diag(out2$d),out2$v))
out2.mat = proj.onto.15(out2.mat)
err2 = NMAE.and.MSE(out2.mat, testdata,n)
outM5[2,1] = err2$nmae

lambda.out2 = lambda.candid[which.min(SI.o.svd.mse[1,])]
out2 = softImpute(traindata, rank.max = 50, lambda = lambda.out2, 
				type = "svd", maxit=500)
out2.mat = out2$u %*% (tcrossprod(diag(out2$d),out2$v))
out2.mat = proj.onto.15(out2.mat)
err2 = NMAE.and.MSE(out2.mat, testdata,n)
outM5[2,2] = err2$mse

#
lambda.out3 = lambda.candid[which.min(apply(SI.r.als.nmae,2,min))]
rank.out3 = r.candid[which.min(apply(SI.r.als.nmae,1,min))]
out3 = softImpute(traindata, rank.max = rank.out3, lambda = lambda.out3, 
				type = "als", maxit=500)
out3.mat = out3$u %*% (tcrossprod(diag(out3$d),out3$v))
out3.mat = proj.onto.15(out3.mat)
err3 = NMAE.and.MSE(out3.mat, testdata,n)
outM5[3,1] = err3$nmae

lambda.out3 = lambda.candid[which.min(apply(SI.r.als.mse,2,min))]
rank.out3 = r.candid[which.min(apply(SI.r.als.mse,1,min))]
out3 = softImpute(traindata, rank.max = rank.out3, lambda = lambda.out3, 
				type = "als", maxit=500)
out3.mat = out3$u %*% (tcrossprod(diag(out3$d),out3$v))
out3.mat = proj.onto.15(out3.mat)
err3 = NMAE.and.MSE(out3.mat, testdata,n)
outM5[3,2] = err3$mse

#
lambda.out4 = lambda.candid[which.min(apply(SI.r.svd.nmae,2,min))]
rank.out4 = r.candid[which.min(apply(SI.r.svd.nmae,1,min))]
out4 = softImpute(traindata, rank.max = rank.out4, lambda = lambda.out4, 
				type = "svd", maxit=500)
out4.mat = out4$u %*% (tcrossprod(diag(out4$d),out4$v))
out4.mat = proj.onto.15(out4.mat)
err4 = NMAE.and.MSE(out4.mat, testdata,n)
outM5[4,1] = err4$nmae

lambda.out4 = lambda.candid[which.min(apply(SI.r.svd.mse,2,min))]
rank.out4 = r.candid[which.min(apply(SI.r.svd.mse,1,min))]
out4 = softImpute(traindata, rank.max = rank.out4, lambda = lambda.out4, 
				type = "svd", maxit=500)
out4.mat = out4$u %*% (tcrossprod(diag(out4$d),out4$v))
out4.mat = proj.onto.15(out4.mat)
err4 = NMAE.and.MSE(out4.mat, testdata,n)
outM5[4,2] = err4$mse

save(outM5,file="movielens_outM5.RData")


