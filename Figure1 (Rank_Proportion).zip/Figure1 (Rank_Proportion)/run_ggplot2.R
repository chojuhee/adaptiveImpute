rm(list=ls())
path="C:/research/Matrix completion/AI-condor/Simulation/Rank_Proportion/"
path="C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/Simulation/Rank_Proportion/"

r.set=c(5,10,20,50)
p.set=c(10,20,50,90)


result1=c(); result2=c(); result3=c(); result4=c(); result5=c()

for(r in r.set){
for(p in p.set){

Result1=c(); Result2=c(); Result3=c(); Result4=c(); Result5=c()

for(itr in 0:99){
name=paste(path, "Matrix-",r,"-",p, "-result/job", itr, sep="")

if(file.exists(file.path(name, "result.RData"))){
setwd(name)
load("result.RData")

Result1=rbind(Result1, t(result.M1))
Result2=rbind(Result2, t(result.M2))
Result3=rbind(Result3, t(result.M3))
Result4=rbind(Result4, t(result.M4))
Result5=rbind(Result5, t(result.M5))
}
}

result1=rbind(result1, apply(Result1,2, mean))
result2=rbind(result2, apply(Result2,2, mean))
result3=rbind(result3, apply(Result3,2, mean))
result4=rbind(result4, apply(Result4,2, mean))
result5=rbind(result5, apply(Result5,2, mean))
}
}



temp1=c()
for(i in 1:3){
temp1[[i]]=
cbind(
result1[1:4,i],
result2[1:4,i],
result3[1:4,i],
result4[1:4,i],
result5[1:4,i] )
}



temp2=c()
for(i in 1:3){
temp2[[i]]=
cbind(
result1[5:8,i],
result2[5:8,i],
result3[5:8,i],
result4[5:8,i],
result5[5:8,i] )
}

temp3=c()
for(i in 1:3){
temp3[[i]]=
cbind(
result1[9:12,i],
result2[9:12,i],
result3[9:12,i],
result4[9:12,i],
result5[9:12,i] )
}


temp4=c()
for(i in 1:3){
temp4[[i]]=
cbind(
result1[13:16,i],
result2[13:16,i],
result3[13:16,i],
result4[13:16,i],
result5[13:16,i] )
}


method.prep = c("AdaptImpute","softIm","softIm-Rank","softIm-ALS","softIm-ALS-Rank")
method = c()
for(i in 1:5) method = c(method,rep(method.prep[i],dim(temp1[[1]])[1]))
method = rep(method,3)
p = rep(c(0.1,0.2,0.5,0.9),5)
p = rep(p,3)
TTT.prep = c("  Total"," Training","Test")
TTT = c()
for(i in 1:3) TTT = c(TTT,rep(TTT.prep[i],dim(temp1[[1]])[1]*dim(temp1[[1]])[2]))

temp.prep = temp1
temp = c()
for(i in 1:3){
	numer = matrix(temp.prep[[i]][,3],dim(temp1[[1]])[1],5,byrow=FALSE)
	temp[[i]] = numer/temp.prep[[i]]
}
RelativeEfficiency = c(as.vector(temp[[1]]),as.vector(temp[[2]]),as.vector(temp[[3]]))
dat1 = data.frame(method,p,TTT,RelativeEfficiency)
head(dat1)
dat1$rank = " Rank=5"


temp.prep = temp2
temp = c()
for(i in 1:3){
	numer = matrix(temp.prep[[i]][,3],dim(temp1[[1]])[1],5,byrow=FALSE)
	temp[[i]] = numer/temp.prep[[i]]
}
RelativeEfficiency = c(as.vector(temp[[1]]),as.vector(temp[[2]]),as.vector(temp[[3]]))
dat2 = data.frame(method,p,TTT,RelativeEfficiency)
head(dat2)
dat2$rank = "Rank=10"


temp.prep = temp3
temp = c()
for(i in 1:3){
	numer = matrix(temp.prep[[i]][,3],dim(temp1[[1]])[1],5,byrow=FALSE)
	temp[[i]] = numer/temp.prep[[i]]
}
RelativeEfficiency = c(as.vector(temp[[1]]),as.vector(temp[[2]]),as.vector(temp[[3]]))
dat3 = data.frame(method,p,TTT,RelativeEfficiency)
head(dat3)
dat3$rank = "Rank=20"

temp.prep = temp4
temp = c()
for(i in 1:3){
	numer = matrix(temp.prep[[i]][,3],dim(temp1[[1]])[1],5,byrow=FALSE)
	temp[[i]] = numer/temp.prep[[i]]
}
RelativeEfficiency = c(as.vector(temp[[1]]),as.vector(temp[[2]]),as.vector(temp[[3]]))
dat4 = data.frame(method,p,TTT,RelativeEfficiency)
head(dat4)
dat4$rank = "Rank=50"

dat = rbind(dat1,dat2,dat3,dat4)
head(dat)
tail(dat)



library(ggplot2)
library(dplyr)

pdf("C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/Simulation/Rank_Proportion/heyFigure1.pdf",
	width = 8, height = 8.48)
ggplot(dat, aes(p, log(RelativeEfficiency), color = method, pch = method, lty = method)) +
    geom_point(size=2) +
    geom_line(size=0.5) +
    facet_grid(rank ~ TTT)
dev.off()


