rm(list=ls())
path="C:/research/Matrix completion/AI-condor/Simulation/Iteration/"
path="C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/Simulation/Iteration/"

r.set=c(5,10,20)
p.set=c(1,2,3,4)


result1=c(); result2=c(); result3=c(); result4=c(); result5=c()
result6=c(); result7=c(); result8=c()

for(r in r.set){
  for(p in p.set){

    Result1=c(); Result2=c(); Result3=c(); Result4=c(); Result5=c()
    Result6=c(); Result7=c(); Result8=c()

    for(itr in 0:99){
      name=paste(path, "Matrix-",r,"-",p, "-result/job", itr, sep="")

      if(file.exists(file.path(name, "result.RData"))){
        setwd(name)
        load("result.RData")

        Result1=rbind(Result1, t(result.M01))
        Result2=rbind(Result2, t(result.M02))
        Result3=rbind(Result3, t(result.M03))
        Result4=rbind(Result4, t(result.M04))
        Result5=rbind(Result5, t(result.M05))
        Result6=rbind(Result6, t(result.M06))
        Result7=rbind(Result7, t(result.M07))
        Result8=rbind(Result8, t(result.M08))
      }
    }

    result1=rbind(result1, apply(Result1,2, mean))
    result2=rbind(result2, apply(Result2,2, mean))
    result3=rbind(result3, apply(Result3,2, mean))
    result4=rbind(result4, apply(Result4,2, mean))
    result5=rbind(result5, apply(Result5,2, mean))
    result6=rbind(result6, apply(Result6,2, mean))
    result7=rbind(result7, apply(Result7,2, mean))
    result8=rbind(result8, apply(Result8,2, mean))

  }
}



temp1=c()
for(i in 1:3){
  temp1[[i]]=
    cbind(
      result1[1:4,i],
      result2[1:4,i],
      result3[1:4,i],
      result4[1:4,i],
      result5[1:4,i],
      result6[1:4,i],
      result7[1:4,i],
      result8[1:4,i] )
}



temp2=c()
for(i in 1:3){
  temp2[[i]]=
    cbind(
      result1[5:8,i],
      result2[5:8,i],
      result3[5:8,i],
      result4[5:8,i],
      result5[5:8,i],
      result6[5:8,i],
      result7[5:8,i],
      result8[5:8,i] )
}

temp3=c()
for(i in 1:3){
  temp3[[i]]=
    cbind(
      result1[9:12,i],
      result2[9:12,i],
      result3[9:12,i],
      result4[9:12,i],
      result5[9:12,i],
      result6[9:12,i],
      result7[9:12,i],
      result8[9:12,i] )
}






r.set=c(50)
p.set=c(1,2,3,4)


result1=c(); result2=c(); result3=c(); result4=c(); result5=c()
result6=c(); result7=c(); result8=c(); result9=c(); result10=c()
result11=c(); result12=c()

for(r in r.set){
  for(p in p.set){

    Result1=c(); Result2=c(); Result3=c(); Result4=c(); Result5=c()
    Result6=c(); Result7=c(); Result8=c(); Result9=c(); Result10=c()
    Result11=c(); Result12=c()

    for(itr in 0:99){
      name=paste(path, "Matrix-",r,"-",p, "-result/job", itr, sep="")

      if(file.exists(file.path(name, "result.RData"))){
        setwd(name)
        load("result.RData")

        Result1=rbind(Result1, t(result.M01))
        Result2=rbind(Result2, t(result.M02))
        Result3=rbind(Result3, t(result.M03))
        Result4=rbind(Result4, t(result.M04))
        Result5=rbind(Result5, t(result.M05))
        Result6=rbind(Result6, t(result.M06))
        Result7=rbind(Result7, t(result.M07))
        Result8=rbind(Result8, t(result.M08))
        Result9=rbind(Result9, t(result.M09))
        Result10=rbind(Result10, t(result.M10))
        Result11=rbind(Result11, t(result.M11))
        Result12=rbind(Result12, t(result.M12))


      }
    }

    result1=rbind(result1, apply(Result1,2, mean))
    result2=rbind(result2, apply(Result2,2, mean))
    result3=rbind(result3, apply(Result3,2, mean))
    result4=rbind(result4, apply(Result4,2, mean))
    result5=rbind(result5, apply(Result5,2, mean))
    result6=rbind(result6, apply(Result6,2, mean))
    result7=rbind(result7, apply(Result7,2, mean))
    result8=rbind(result8, apply(Result8,2, mean))
    result9=rbind(result9, apply(Result9,2, mean))
    result10=rbind(result10, apply(Result10,2, mean))
    result11=rbind(result11, apply(Result11,2, mean))
    result12=rbind(result12, apply(Result12,2, mean))

  }
}


temp4=c()
for(i in 1:3){
  temp4[[i]]=
    cbind(
      result1[1:4,i],
      result2[1:4,i],
      result3[1:4,i],
      result4[1:4,i],
      result5[1:4,i],
      result6[1:4,i] ,
      result7[1:4,i] ,
      result8[1:4,i],
      result9[1:4,i],
      result10[1:4,i],
      result11[1:4,i],
      result12[1:4,i] )
}



itr.num.prep = c(1,5,10, 20, 50, 100, 500 ,1000)
itr.num = c()
for(i in 1:length(itr.num.prep)) itr.num = c(itr.num,rep(itr.num.prep[i],dim(temp1[[1]])[1]))
itr.num = rep(itr.num,3)
noise = rep(c("Noise Level= 0.1", "Noise Level= 1", "Noise Level= 5",  "Noise Level=10"),
		length(itr.num.prep))
noise = rep(noise,3)
TTT.prep = c("  Total"," Training","Test")
TTT = c()
for(i in 1:3) TTT = c(TTT,rep(TTT.prep[i],dim(temp1[[1]])[1]*dim(temp1[[1]])[2]))

temp = temp1
Errors = c(as.vector(temp[[1]]),as.vector(temp[[2]]),as.vector(temp[[3]]))
dat1 = data.frame(itr.num,noise,TTT,Errors)
head(dat1)
dat1$rank = " Rank=5"


temp = temp2
Errors = c(as.vector(temp[[1]]),as.vector(temp[[2]]),as.vector(temp[[3]]))
dat2 = data.frame(itr.num,noise,TTT,Errors)
head(dat2)
dat2$rank = "Rank=10"


temp = temp3
Errors = c(as.vector(temp[[1]]),as.vector(temp[[2]]),as.vector(temp[[3]]))
dat3 = data.frame(itr.num,noise,TTT,Errors)
head(dat3)
dat3$rank = "Rank=20"


itr.num.prep = c(1,5,10, 20, 50, 100, 500 ,1000, 2000, 3000, 3500, 4000)
itr.num = c()
for(i in 1:length(itr.num.prep)) itr.num = c(itr.num,rep(itr.num.prep[i],dim(temp1[[1]])[1]))
itr.num = rep(itr.num,3)
noise = rep(c("Noise Level= 0.1", "Noise Level= 1", "Noise Level= 5",  "Noise Level=10"),
		length(itr.num.prep))
noise = rep(noise,3)
TTT.prep = c("  Total"," Training","Test")
TTT = c()
for(i in 1:3) TTT = c(TTT,rep(TTT.prep[i],dim(temp1[[1]])[1]*dim(temp4[[1]])[2]))

temp = temp4
Errors = c(as.vector(temp[[1]]),as.vector(temp[[2]]),as.vector(temp[[3]]))
dat4 = data.frame(itr.num,noise,TTT,Errors)
head(dat4)
dat4$rank = "Rank=50"

dat = rbind(dat1,dat2,dat3,dat4)
head(dat)
tail(dat)



library(ggplot2)
library(dplyr)

pdf("C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/Simulation/Iteration/heyFigure5.pdf",
	width = 8, height = 8.48)
ggplot(dat, aes(itr.num, log(Errors), color = noise, pch = noise, lty = noise)) +
    geom_point(size=2) +
    geom_line(size=0.5) +
    facet_wrap(rank ~ TTT, nrow=4, ncol=3,scales = "free")
dev.off()

pdf("C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/Simulation/Iteration/heyFigure51.pdf",
	width = 8, height = 8.48)
ggplot(dat, aes(itr.num, log(Errors), color = noise, pch = noise, lty = noise)) +
    geom_point(size=2) +
    geom_line(size=0.5) +
    facet_grid(rank ~ TTT)
dev.off()

itr.num.prep = c(1,5,10, 20, 50, 100, 500 ,1000)
itr.num = c()
for(i in 1:length(itr.num.prep)) itr.num = c(itr.num,rep(itr.num.prep[i],dim(temp1[[1]])[1]))
itr.num = rep(itr.num,3)
noise = rep(c("Noise Level= 0.1", "Noise Level= 1", "Noise Level= 5",  "Noise Level=10"),
		length(itr.num.prep))
noise = rep(noise,3)
TTT.prep = c("  Total"," Training","Test")
TTT = c()
for(i in 1:3) TTT = c(TTT,rep(TTT.prep[i],dim(temp1[[1]])[1]*dim(temp1[[1]])[2]))

temp = temp4
Errors = c(as.vector(temp[[1]][,c(1:8)]),as.vector(temp[[2]][,c(1:8)]),as.vector(temp[[3]][,c(1:8)]))
dat4 = data.frame(itr.num,noise,TTT,Errors)
head(dat4)
dat4$rank = "Rank=50"

dat = rbind(dat1,dat2,dat3,dat4)
head(dat)
tail(dat)

pdf("C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/Simulation/Iteration/heyFigure52.pdf",
	width = 8, height = 8.48)
ggplot(dat, aes(itr.num, log(Errors), color = noise, pch = noise, lty = noise)) +
    geom_point(size=2) +
    geom_line(size=0.5) +
    facet_grid(rank ~ TTT)
dev.off()

lims = data.frame(rowID=c(1:12))
rank.prep = c("Rank=5","Rank=10","Rank=20","Rank=50")
lims$TTT = rep(c("Total","Training","Test"),length(rank.prep))
rank = c()
for(i in 1:4) rank = c(rank, rep(rank.prep[i],3))
lims$rank = rank
lims$xmin = 0
lims$xmax = c(rep(1000,9),rep(4000,3))
lims$ymin = -14
lims$ymax = 0
lims



