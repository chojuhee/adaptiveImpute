rm(list=ls())
path="C:/research/Matrix completion/AI-condor/Simulation/Correlated/"
path="C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/Simulation/Correlated/"

rho.set=c(0, 1,3,7)

result1=c(); result2=c(); result3=c(); result4=c(); result5=c()
result.lambda=c()
for(rho in rho.set){

Result1=c(); Result2=c(); Result3=c(); Result4=c(); Result5=c()
lambda.temp=c()

for(itr in 0:99){
name=paste(path, "Matrix-Cor-",rho, "-result/job", itr, sep="")

if(file.exists(file.path(name, "result.RData"))){
setwd(name)
load("result.RData")

lambda.temp=c(lambda.temp, lambda)

Result1=rbind(Result1, t(result[,1]))
Result2=rbind(Result2, t(result[,2]))
Result3=rbind(Result3, t(result[,3]))
Result4=rbind(Result4, t(result[,4]))
Result5=rbind(Result5, t(result[,5]))
}
}

result1=rbind(result1, apply(Result1,2, mean))
result2=rbind(result2, apply(Result2,2, mean))
result3=rbind(result3, apply(Result3,2, mean))
result4=rbind(result4, apply(Result4,2, mean))
result5=rbind(result5, apply(Result5,2, mean))
result.lambda=rbind(result.lambda, mean(lambda.temp))
}

temp1=cbind(result1[,1],
result2[,1],
result3[,1],
result4[,1],
result5[,1])

temp2=cbind(result1[,2],
result2[,2],
result3[,2],
result4[,2],
result5[,2])

temp3=cbind(result1[,3],
result2[,3],
result3[,3],
result4[,3],
result5[,3])


method.prep = c("AdaptImpute","softIm","softIm-Rank","softIm-ALS","softIm-ALS-Rank")
method = c()
for(i in 1:5) method = c(method,rep(method.prep[i],dim(temp1)[1]))
method = rep(method,3)
p = rep(c(0,0.1,0.3, 0.7),5)
p = rep(p,3)
TTT.prep = c("  Total"," Training","Test")
TTT = c()
for(i in 1:3) TTT = c(TTT,rep(TTT.prep[i],dim(temp1)[1]*dim(temp1)[2]))
Errors = c(as.vector(temp1),as.vector(temp2),as.vector(temp3))
dat = data.frame(method,p,TTT,Errors)
head(dat)
tail(dat)


library(ggplot2)
library(dplyr)

pdf("C:/Users/choju/Dropbox/My Research/LRMC/jcgs-template/Simulation/Correlated/heyFigure7.pdf",
	width = 8, height = 4)
ggplot(dat, aes(p, log(Errors), color = method, pch = method, lty = method)) +
    geom_point(size=2) +
    geom_line(size=0.5) +
    facet_grid(~TTT)
dev.off()
